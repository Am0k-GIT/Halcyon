/* ngc_expr.h */

#ifndef _NGC_EXPR_H_
#define _NGC_EXPR_H_

status_code_t ngc_eval_expression (char *line, uint_fast8_t *pos, float *value);

#endif
